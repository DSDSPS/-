﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test_01
{
    public partial class Form1 : Form
    {
        // 드릴 초기 위치
        private int drillY = 0;

        // 드릴 속도
        private int drillSpeed = 8;

        // 드릴 버튼의 크기
        private int buttonWidth;
        private int buttonHeight;

        // 획득 상태를 나타내는 변수
        private bool isCollected = false;

        public Form1()
        {
            InitializeComponent();
            // 드릴 버튼의 크기 설정
            buttonWidth = button1.Width;
            buttonHeight = button1.Height;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void 드릴_Click(object sender, EventArgs e)
        {
            // 드릴 버튼을 클릭하여 드릴의 위치를 아래로 이동시킵니다.
            drillY += drillSpeed;

            // 드릴의 위치를 변경하여 아래로 이동시킵니다.
            MoveDrill(drillY);

            // 여러 PictureBox와 닿았을 때 "획득했습니다" 메시지 표시
            CheckCollisionWithPictureBoxes();
        }

        // 드릴을 아래로 이동시키는 메서드
        private void MoveDrill(int newY)
        {
            // PictureBox 컨트롤의 위치를 변경하여 드릴을 이동시킵니다.
            button1.Location = new System.Drawing.Point(button1.Location.X, newY);
        }

        // 여러 PictureBox와 충돌 확인 후 "획득했습니다" 메시지 표시
        private void CheckCollisionWithPictureBoxes()
        {
            // 각 PictureBox 컨트롤과의 충돌을 확인하고 획득 메시지 표시
            foreach (Control control in Controls)
            {
                if (control is PictureBox)
                {
                    PictureBox pictureBox = (PictureBox)control;
                    // 드릴 버튼과 PictureBox가 충돌하는지 확인합니다.
                    if (IsDrillTouchingPictureBox(pictureBox))
                    {
                        MessageBox.Show("획득했습니다");
                        isCollected = true; // 획득 상태를 true로 변경
                        return; // 한 번 충돌이 확인되면 더 이상 검사하지 않고 함수 종료
                    }
                }

            }
        }


        // 드릴 버튼과 특정 PictureBox가 충돌하는지 확인하는 메서드
        private bool IsDrillTouchingPictureBox(PictureBox pictureBox)
        {
            // 드릴 버튼의 현재 위치와 PictureBox의 위치를 가져옵니다.
            int drillX = button1.Location.X;
            int pictureBoxX = pictureBox.Location.X;
            int pictureBoxY = pictureBox.Location.Y;

            // 드릴 버튼의 아래쪽이 PictureBox의 위쪽과 겹치는지 확인합니다.
            if (drillX >= pictureBoxX && drillX <= pictureBoxX + pictureBox.Width &&
                drillY + buttonHeight >= pictureBoxY && drillY + buttonHeight <= pictureBoxY + pictureBox.Height)
            {
                return true; // 충돌이 확인되면 true 반환
            }

            return false; // 충돌이 없으면 false 반환
        }


        private void pictureBox24_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox19_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox23_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox18_Click(object sender, EventArgs e)
        {

        }



        private void 에메랄드_Click(object sender, EventArgs e)
        {

        }
    }
}

